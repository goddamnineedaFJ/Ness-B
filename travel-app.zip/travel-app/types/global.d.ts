declare module 'd3' {
  export interface D3ZoomEvent<Element extends Element, Datum> {
    transform: ZoomTransform
    sourceEvent: any
    target: any
    type: string
  }

  export interface ZoomTransform {
    x: number
    y: number
    k: number
    translate(x: number, y: number): ZoomTransform
    scale(k: number): ZoomTransform
    apply(point: [number, number]): [number, number]
    applyX(x: number): number
    applyY(y: number): number
    invert(point: [number, number]): [number, number]
    invertX(x: number): number
    invertY(y: number): number
    rescaleX<T extends { invert(x: number): number; domain(): number[]; range(): number[] }>(scale: T): T
    rescaleY<T extends { invert(x: number): number; domain(): number[]; range(): number[] }>(scale: T): T
    toString(): string
  }

  export interface Selection<Element extends Element, Datum, ParentElement extends Element, ParentDatum> {
    attr(name: string, value: any): this
    attr(name: string): string
    call(func: any, ...args: any[]): this
    selectAll(selector: string): Selection<Element, any, any, any>
    data(data: any[]): Selection<Element, any, any, any>
    enter(): Selection<Element, any, any, any>
    append(name: string): Selection<Element, any, any, any>
    on(event: string, listener: any): this
    transition(): Transition<Element, any, any, any>
    node(): Element | null
    remove(): this
  }

  export interface Transition<Element extends Element, Datum, ParentElement extends Element, ParentDatum> {
    duration(duration: number): this
    attr(name: string, value: any): this
    call(func: any, ...args: any[]): this
  }

  export interface GeoProjection {
    scale(scale: number): this
    translate(point: [number, number]): this
  }

  export interface GeoPath {
    (feature: any): string
    bounds(feature: any): [[number, number], [number, number]]
    projection(projection: GeoProjection): this
  }

  export interface ZoomBehavior<Element extends Element, Datum> {
    scaleExtent(extent: [number, number]): this
    on(event: string, listener: any): this
    transform(selection: Selection<Element, Datum, any, any>, transform: ZoomTransform): void
    scaleBy(selection: Selection<Element, Datum, any, any>, k: number): void
  }

  export function select(selector: string | Element): Selection<Element, any, any, any>
  export function geoEquirectangular(): GeoProjection
  export function geoPath(projection?: GeoProjection): GeoPath
  export function zoom(): ZoomBehavior<Element, any>
  export function pointer(event: any, node?: Element | null): [number, number]
  export function tsvParse(text: string): any[]
  export const zoomIdentity: ZoomTransform
}

declare module 'topojson-client' {
  export function feature(topology: any, object: any): any
}

declare module 'lucide-react' {
  export const ZoomIn: React.FC<React.SVGProps<SVGSVGElement>>
  export const ZoomOut: React.FC<React.SVGProps<SVGSVGElement>>
  export const RefreshCw: React.FC<React.SVGProps<SVGSVGElement>>
}

declare module 'framer-motion' {
  export const motion: {
    div: React.FC<React.HTMLAttributes<HTMLDivElement>>
  }
} 