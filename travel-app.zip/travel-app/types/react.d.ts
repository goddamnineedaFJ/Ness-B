declare namespace JSX {
  interface IntrinsicElements {
    div: React.HTMLAttributes<HTMLDivElement>
    span: React.HTMLAttributes<HTMLSpanElement>
    p: React.HTMLAttributes<HTMLParagraphElement>
    h1: React.HTMLAttributes<HTMLHeadingElement>
    h2: React.HTMLAttributes<HTMLHeadingElement>
    h3: React.HTMLAttributes<HTMLHeadingElement>
    ul: React.HTMLAttributes<HTMLUListElement>
    li: React.HTMLAttributes<HTMLLIElement>
    img: React.ImgHTMLAttributes<HTMLImageElement>
    button: React.ButtonHTMLAttributes<HTMLButtonElement>
    svg: React.SVGAttributes<SVGSVGElement>
  }
}

declare module 'react' {
  export interface FC<P = {}> {
    (props: P): React.ReactElement | null
  }

  export interface ReactElement {
    type: string | React.ComponentType<any>
    props: any
    key: string | number | null
  }

  export interface ComponentType<P = {}> {
    (props: P): ReactElement | null
  }

  export interface HTMLAttributes<T> extends AriaAttributes, DOMAttributes<T> {
    className?: string
    style?: React.CSSProperties
  }

  export interface SVGAttributes<T> extends AriaAttributes, DOMAttributes<T> {
    className?: string
    style?: React.CSSProperties
  }

  export interface ButtonHTMLAttributes<T> extends HTMLAttributes<T> {
    onClick?: (event: React.MouseEvent<T>) => void
  }

  export interface ImgHTMLAttributes<T> extends HTMLAttributes<T> {
    src?: string
    alt?: string
  }

  export interface LiHTMLAttributes<T> extends HTMLAttributes<T> {}

  export interface HTMLParagraphElement extends HTMLElement {}
  export interface HTMLHeadingElement extends HTMLElement {}
  export interface HTMLUListElement extends HTMLElement {}
  export interface HTMLLIElement extends HTMLElement {}
  export interface HTMLImageElement extends HTMLElement {}
  export interface HTMLDivElement extends HTMLElement {}
  export interface HTMLButtonElement extends HTMLElement {}
  export interface HTMLElement extends Element {}
  export interface Element extends Node {}
  export interface Node {}

  export interface MouseEvent<T = Element> {
    stopPropagation(): void
  }

  export interface CSSProperties {
    [key: string]: any
  }

  export interface AriaAttributes {}
  export interface DOMAttributes<T> {
    onClick?: (event: MouseEvent<T>) => void
  }

  export function useState<T>(initialState: T | (() => T)): [T, (newState: T | ((prevState: T) => T)) => void]
  export function useEffect(effect: () => void | (() => void), deps?: readonly any[]): void
  export function useRef<T>(initialValue: T | null): { current: T | null }
}

declare module 'next/navigation' {
  export function useRouter(): {
    push: (url: string) => void
  }
} 