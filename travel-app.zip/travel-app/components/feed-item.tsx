"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { Heart, MessageCircle, Bookmark, Share2, MoreHorizontal, ChevronLeft, ChevronRight } from "lucide-react"
import type { FeedItem as FeedItemType } from "@/lib/mock-feed-data"
import { cn } from "@/lib/utils"

interface FeedItemProps {
  item: FeedItemType
}

export function FeedItem({ item }: FeedItemProps) {
  const [isLiked, setIsLiked] = useState(item.isLiked)
  const [isSaved, setIsSaved] = useState(item.isSaved)
  const [likes, setLikes] = useState(item.likes)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showAllComments, setShowAllComments] = useState(false)

  const handleLike = () => {
    if (isLiked) {
      setLikes(likes - 1)
    } else {
      setLikes(likes + 1)
    }
    setIsLiked(!isLiked)
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
  }

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex === item.images.length - 1 ? 0 : prevIndex + 1))
  }

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex === 0 ? item.images.length - 1 : prevIndex - 1))
  }

  const displayComments = showAllComments ? item.comments : item.comments.slice(0, 1)

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <Image
            src={item.user.avatar || "/placeholder.svg"}
            alt={item.user.name}
            width={40}
            height={40}
            className="rounded-full"
          />
          <div>
            <Link href={`/profile/${item.user.username}`} className="font-medium hover:underline">
              {item.user.name}
            </Link>
            <p className="text-sm text-gray-500">
              {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
            </p>
          </div>
        </div>
        <button className="text-gray-500 hover:text-gray-700">
          <MoreHorizontal size={20} />
        </button>
      </div>

      {/* Destination */}
      <div className="px-4 pb-3">
        <Link href={`/country/${item.countryCode.toLowerCase()}`} className="font-medium text-lg hover:underline">
          {item.destination}
          <span className="ml-2 text-xl">
            {item.countryCode === "JP"
              ? "🇯🇵"
              : item.countryCode === "ES"
                ? "🇪🇸"
                : item.countryCode === "ID"
                  ? "🇮🇩"
                  : item.countryCode === "US"
                    ? "🇺🇸"
                    : item.countryCode === "GR"
                      ? "🇬🇷"
                      : "🌍"}
          </span>
        </Link>
        <p className="text-sm text-gray-500">
          {new Date(item.startDate).toLocaleDateString()} - {new Date(item.endDate).toLocaleDateString()}
          <span className="ml-2">({item.duration} days)</span>
        </p>
      </div>

      {/* Description */}
      <div className="px-4 pb-4">
        <p className="text-gray-800">{item.description}</p>
      </div>

      {/* Images */}
      <div className="relative">
        <div className="relative h-64 w-full">
          <Image
            src={item.images[currentImageIndex] || "/placeholder.svg"}
            alt={`Trip to ${item.destination}`}
            fill
            className="object-cover"
          />
        </div>

        {item.images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/30 text-white p-1 rounded-full hover:bg-black/50"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/30 text-white p-1 rounded-full hover:bg-black/50"
            >
              <ChevronRight size={24} />
            </button>

            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
              {item.images.map((_, index) => (
                <div
                  key={index}
                  className={cn(
                    "h-1.5 rounded-full",
                    currentImageIndex === index ? "w-4 bg-white" : "w-1.5 bg-white/60",
                  )}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between p-4 border-t border-gray-100">
        <div className="flex items-center space-x-4">
          <button
            onClick={handleLike}
            className={cn(
              "flex items-center space-x-1",
              isLiked ? "text-red-500" : "text-gray-500 hover:text-gray-700",
            )}
          >
            <Heart size={20} fill={isLiked ? "currentColor" : "none"} />
            <span>{likes}</span>
          </button>

          <button className="flex items-center space-x-1 text-gray-500 hover:text-gray-700">
            <MessageCircle size={20} />
            <span>{item.comments.length}</span>
          </button>

          <button className="text-gray-500 hover:text-gray-700">
            <Share2 size={20} />
          </button>
        </div>

        <button onClick={handleSave} className={cn(isSaved ? "text-blue-500" : "text-gray-500 hover:text-gray-700")}>
          <Bookmark size={20} fill={isSaved ? "currentColor" : "none"} />
        </button>
      </div>

      {/* Comments */}
      {item.comments.length > 0 && (
        <div className="px-4 pb-4">
          {displayComments.map((comment) => (
            <div key={comment.id} className="flex items-start space-x-2 mb-2">
              <Image
                src={comment.user.avatar || "/placeholder.svg"}
                alt={comment.user.name}
                width={32}
                height={32}
                className="rounded-full mt-1"
              />
              <div className="flex-1">
                <div className="bg-gray-100 rounded-lg p-2">
                  <Link href={`/profile/${comment.user.username}`} className="font-medium hover:underline">
                    {comment.user.name}
                  </Link>
                  <p className="text-gray-800">{comment.text}</p>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}

          {item.comments.length > 1 && (
            <button
              onClick={() => setShowAllComments(!showAllComments)}
              className="text-sm text-gray-500 hover:text-gray-700 mt-1"
            >
              {showAllComments ? "Hide comments" : `View all ${item.comments.length} comments`}
            </button>
          )}

          <div className="mt-3 flex items-center space-x-2">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="Your avatar"
              width={32}
              height={32}
              className="rounded-full"
            />
            <input
              type="text"
              placeholder="Add a comment..."
              className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      )}
    </div>
  )
}
