"use client"

import { useState } from "react"
import { ComposableMap, Geographies, Geography, ZoomableGroup } from "react-simple-maps"
import { MapTooltip } from "@/components/map-tooltip"

const geoUrl = "https://raw.githubusercontent.com/d3/d3-geo/main/test/data/world.json"

export default function WorldMap({ darkMode }: { darkMode: boolean }) {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [zoom, setZoom] = useState(1)
  const [content, setContent] = useState("")

  const handleMoveEnd = (position: any) => {
    setPosition(position)
  }

  const handleZoomIn = () => {
    if (zoom >= 4) return
    setZoom(zoom * 2)
  }

  const handleZoomOut = () => {
    if (zoom <= 1) return
    setZoom(zoom / 2)
  }

  return (
    <div className="relative">
      <ComposableMap
        projectionConfig={{
          center: [0, 0],
          scale: 150,
        }}
        width={800}
        height={500}
        style={{ width: "100%", height: "auto" }}
      >
        <ZoomableGroup zoom={zoom} onMoveEnd={handleMoveEnd}>
          <Geographies geography={geoUrl}>
            {({ geographies }) =>
              geographies.map((geo) => (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={darkMode ? "#2D3748" : "#D6D6DA"}
                  stroke={darkMode ? "#718096" : "#FFFFFF"}
                  strokeWidth={0.5}
                  style={{
                    default: {
                      outline: "none",
                    },
                    hover: {
                      fill: "#F53E2D",
                      outline: "none",
                    },
                    pressed: {
                      outline: "none",
                    },
                  }}
                  onMouseEnter={() => {
                    setContent(`${geo.properties.name}`)
                  }}
                  onMouseLeave={() => {
                    setContent("")
                  }}
                />
              ))
            }
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>
      {content && <MapTooltip country={content} position={{ x: 400, y: 100 }} darkMode={darkMode} />}
    </div>
  )
}
