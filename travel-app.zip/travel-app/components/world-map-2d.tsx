"use client"

import React, { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import * as d3 from "d3"
import { feature } from "topojson-client"
import { CountryTooltip } from "./country-tooltip"
import { ZoomIn, ZoomOut, RefreshCw } from "lucide-react"
import { useMapData } from "@/context/map-data-context"
import { motion } from "framer-motion"

interface WorldMap2DProps {
  width?: number
  height?: number
}

interface CountryData {
  id: string
  name: string
  properties: any
}

interface CountryInfo {
  name: string
  description: string
  majorCities: string[]
  photos: string[]
  capital: string[]
  population: number
  region: string
  subregion: string
  languages: Record<string, string>
  flag: string
}

interface D3ZoomEvent extends d3.D3ZoomEvent<SVGSVGElement, unknown> {
  transform: d3.ZoomTransform
}

interface CountryFeature {
  id: string
  properties: any
}

export default function WorldMap2D({ width = 960, height = 500 }: WorldMap2DProps) {
  const router = useRouter()
  const { mapData } = useMapData()
  const mapRef = useRef<SVGSVGElement>(null)
  const [hoveredCountry, setHoveredCountry] = useState<CountryData | null>(null)
  const [selectedCountry, setSelectedCountry] = useState<CountryInfo | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const [mapLoaded, setMapLoaded] = useState(false)
  const [countryData, setCountryData] = useState<CountryData[]>([])
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [countriesInfo, setCountriesInfo] = useState<Record<string, CountryInfo>>({})

  // Fetch country data from REST Countries API
  useEffect(() => {
    const fetchCountryData = async () => {
      try {
        const response = await fetch("https://restcountries.com/v3.1/all")
        const data = await response.json()
        
        const countryInfoMap: Record<string, CountryInfo> = {}
        data.forEach((country: any) => {
          // Convert country code to match the map data format (numeric)
          const countryCode = country.cca3
          countryInfoMap[countryCode] = {
            name: country.name.common,
            description: `${country.name.common} is a country in ${country.region}. ${country.subregion ? `It's located in ${country.subregion}.` : ''} ${country.capital ? `The capital is ${country.capital[0]}.` : ''}`,
            majorCities: country.capital ? [country.capital[0]] : [],
            photos: [country.flags.png], // Using flag as a placeholder for photos
            capital: country.capital || [],
            population: country.population,
            region: country.region,
            subregion: country.subregion,
            languages: country.languages || {},
            flag: country.flags.png
          }
        })
        
        setCountriesInfo(countryInfoMap)
      } catch (error) {
        console.error("Error fetching country data:", error)
      }
    }

    fetchCountryData()
  }, [])

  // Update dimensions on window resize
  useEffect(() => {
    const updateDimensions = () => {
      if (mapRef.current) {
        const { width, height } = mapRef.current.getBoundingClientRect()
        setDimensions({ width, height })
      }
    }

    updateDimensions()
    window.addEventListener("resize", updateDimensions)
    return () => window.removeEventListener("resize", updateDimensions)
  }, [])

  // Load and render the world map
  useEffect(() => {
    if (!mapRef.current || dimensions.width === 0) return

    try {
      const svg = d3.select(mapRef.current)
      svg.selectAll("*").remove()

      const width = dimensions.width
      const height = dimensions.height

      // Create a responsive container
      const container = svg
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", `0 0 ${width} ${height}`)
        .attr("preserveAspectRatio", "xMidYMid meet")
        .append("g")

      // Define map projection
      const projection = d3
        .geoEquirectangular()
        .scale(width / 6.28)
        .translate([width / 2, height / 2])

      // Create path generator
      const pathGenerator = d3.geoPath().projection(projection)

      // Set up zoom behavior
      const zoom = d3
        .zoom()
        .scaleExtent([1, 8])
        .on("zoom", (event: D3ZoomEvent) => {
          container.attr("transform", event.transform)

          if (hoveredCountry) {
            const [x, y] = d3.pointer(event)
            setTooltipPosition({
              x: event.transform.invertX(x),
              y: event.transform.invertY(y),
            })
          }
        })

      zoomRef.current = zoom
      svg.call(zoom as any)

      // Load world map data
      const loadMapData = async () => {
        try {
          let worldData
          let countryNames: Map<string, string>

          if (mapData) {
            worldData = mapData.worldData
            countryNames = mapData.countryNames
          } else {
            const response = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json")
            worldData = await response.json()

            const namesResponse = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.tsv")
            const namesText = await namesResponse.text()
            const names = d3.tsvParse(namesText)

            countryNames = new Map<string, string>()
            names.forEach((d: any) => {
              countryNames.set(d.iso_n3, d.name)
            })
          }

          const countries = feature(worldData, worldData.objects.countries).features

          const countries_data = countries.map((country: any) => ({
            id: country.id,
            name: countryNames.get(country.id) || "Unknown",
            properties: country.properties,
          }))

          setCountryData(countries_data)

          // Draw countries
          container
            .selectAll("path")
            .data(countries)
            .enter()
            .append("path")
            .attr("d", pathGenerator as any)
            .attr("class", "country")
            .attr("id", (d: any) => `country-${d.id}`)
            .attr("fill", "#f8f8f8")
            .attr("stroke", "#ddd")
            .attr("stroke-width", 0.5)
            .on("mousemove", function (this: SVGPathElement, event: MouseEvent, d: CountryFeature) {
              const [x, y] = d3.pointer(event, svg.node())
              setTooltipPosition({ x, y })

              const country = countries_data.find((c: CountryData) => c.id === d.id)
              if (country) {
                setHoveredCountry(country)
              }

              d3.select(this).transition().duration(200).attr("fill", "#ffcccb")
            })
            .on("mouseleave", function (this: SVGPathElement) {
              setHoveredCountry(null)
              d3.select(this).transition().duration(200).attr("fill", "#f8f8f8")
            })
            .on("click", (event: MouseEvent, d: CountryFeature) => {
              event.stopPropagation()

              const country = countries_data.find((c: CountryData) => c.id === d.id)
              if (country) {
                // Get country info from the REST Countries API data
                const countryInfo = countriesInfo[d.id]
                if (countryInfo) {
                  setSelectedCountry(countryInfo)
                }

                // Calculate the center of the clicked country
                const bounds = pathGenerator.bounds(d)
                const centerX = (bounds[0][0] + bounds[1][0]) / 2
                const centerY = (bounds[0][1] + bounds[1][1]) / 2

                // Zoom to the country
                const scale = 4
                const transform = d3.zoomIdentity
                  .translate(width / 2, height / 2)
                  .scale(scale)
                  .translate(-centerX, -centerY)

                svg
                  .transition()
                  .duration(750)
                  .call(zoom.transform as any, transform)
              }
            })

          setMapLoaded(true)
          setError(null)
        } catch (error) {
          console.error("Error loading map data:", error)
          setError("Failed to load map data. Please try again.")
          setMapLoaded(false)
        }
      }

      loadMapData()
    } catch (error) {
      console.error("Error rendering map:", error)
      setError("Failed to render map. Please try again.")
      setMapLoaded(false)
    }
  }, [dimensions, router, mapData, countriesInfo])

  // Zoom control handlers
  const handleZoomIn = () => {
    if (mapRef.current && zoomRef.current) {
      d3.select(mapRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 1.5)
    }
  }

  const handleZoomOut = () => {
    if (mapRef.current && zoomRef.current) {
      d3.select(mapRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 0.75)
    }
  }

  const handleResetZoom = () => {
    if (mapRef.current && zoomRef.current) {
      d3.select(mapRef.current).transition().duration(500).call(zoomRef.current.transform, d3.zoomIdentity)
    }
  }

  return (
    <div className="relative w-full h-full bg-white rounded-lg shadow-sm border border-gray-100">
      {!mapLoaded && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 p-4">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Reload
          </button>
        </div>
      )}

      <div className="flex">
        <div className="flex-1">
          <svg ref={mapRef} className="w-full h-full" />
        </div>

        {selectedCountry && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="w-1/3 p-6 bg-white border-l border-gray-200 overflow-y-auto"
          >
            <div className="flex items-center mb-4">
              <img src={selectedCountry.flag} alt={`${selectedCountry.name} flag`} className="w-8 h-6 mr-3" />
              <h2 className="text-2xl font-bold">{selectedCountry.name}</h2>
            </div>
            
            <p className="text-gray-600 mb-6">{selectedCountry.description}</p>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Capital</h3>
              <p className="text-gray-600">{selectedCountry.capital[0]}</p>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Population</h3>
              <p className="text-gray-600">{selectedCountry.population.toLocaleString()}</p>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Region</h3>
              <p className="text-gray-600">{selectedCountry.region}</p>
              {selectedCountry.subregion && (
                <p className="text-gray-600 text-sm">{selectedCountry.subregion}</p>
              )}
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Languages</h3>
              <ul className="space-y-1">
                {Object.entries(selectedCountry.languages).map(([code, name]) => (
                  <li key={code} className="text-gray-600">
                    {name}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </div>

      {hoveredCountry && <CountryTooltip country={hoveredCountry.name} position={tooltipPosition} />}

      {/* Zoom controls */}
      <div className="absolute bottom-4 left-4 flex space-x-2">
        <button
          onClick={handleZoomIn}
          className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50"
          aria-label="Zoom in"
        >
          <ZoomIn className="h-5 w-5" />
        </button>
        <button
          onClick={handleZoomOut}
          className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50"
          aria-label="Zoom out"
        >
          <ZoomOut className="h-5 w-5" />
        </button>
        <button
          onClick={handleResetZoom}
          className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50"
          aria-label="Reset zoom"
        >
          <RefreshCw className="h-5 w-5" />
        </button>
      </div>
    </div>
  )
}
