"use client"

import { useState } from "react"
import Image from "next/image"
import {
  Heart,
  MessageCircle,
  Share2,
  MapPin,
  Calendar,
  Camera,
  Star,
  Award,
  Plane,
  MoreHorizontal,
} from "lucide-react"
import type { FriendActivity as FriendActivityType } from "@/lib/mock-friends-data"
import { cn } from "@/lib/utils"

interface FriendActivityProps {
  activity: FriendActivityType
  friendName: string
  friendAvatar: string
  friendUsername: string
}

export function FriendActivity({ activity, friendName, friendAvatar, friendUsername }: FriendActivityProps) {
  const [liked, setLiked] = useState(activity.liked || false)
  const [likeCount, setLikeCount] = useState(activity.likes)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showComments, setShowComments] = useState(false)

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setLiked(!liked)
  }

  const getActivityIcon = () => {
    switch (activity.type) {
      case "trip":
        return <Plane className="h-5 w-5 text-blue-500" />
      case "photo":
        return <Camera className="h-5 w-5 text-purple-500" />
      case "review":
        return <Star className="h-5 w-5 text-yellow-500" />
      case "check-in":
        return <MapPin className="h-5 w-5 text-red-500" />
      case "achievement":
        return <Award className="h-5 w-5 text-green-500" />
      case "booking":
        return <Calendar className="h-5 w-5 text-orange-500" />
      default:
        return <MapPin className="h-5 w-5 text-gray-500" />
    }
  }

  const nextImage = () => {
    if (activity.media && currentImageIndex < activity.media.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1)
    }
  }

  const prevImage = () => {
    if (currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 mb-4 overflow-hidden">
      {/* Header */}
      <div className="flex items-center p-4">
        <Image
          src={friendAvatar || "/placeholder.svg"}
          alt={friendName}
          width={40}
          height={40}
          className="rounded-full object-cover"
        />
        <div className="ml-3 flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-sm">{friendName}</h3>
              <p className="text-xs text-gray-500">@{friendUsername}</p>
            </div>
            <div className="flex items-center">
              <span className="text-xs text-gray-500 mr-2">{activity.timestamp}</span>
              <button className="text-gray-400">
                <MoreHorizontal className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Activity Type */}
      <div className="px-4 pb-3 flex items-center">
        {getActivityIcon()}
        <span className="ml-2 text-sm text-gray-600 capitalize">{activity.type}</span>
        {activity.location && (
          <div className="ml-auto flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-1" />
            <span>
              {activity.location.emoji} {activity.location.name}, {activity.location.country}
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className="text-sm">{activity.content}</p>
      </div>

      {/* Media */}
      {activity.media && activity.media.length > 0 && (
        <div className="relative">
          <Image
            src={activity.media[currentImageIndex].url || "/placeholder.svg"}
            alt="Activity media"
            width={600}
            height={400}
            className="w-full h-64 object-cover"
          />

          {activity.media.length > 1 && (
            <>
              <button
                onClick={prevImage}
                disabled={currentImageIndex === 0}
                className={cn(
                  "absolute top-1/2 left-2 -translate-y-1/2 bg-black/30 text-white rounded-full p-1",
                  currentImageIndex === 0 ? "opacity-30" : "opacity-70 hover:opacity-100",
                )}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
              </button>
              <button
                onClick={nextImage}
                disabled={currentImageIndex === activity.media.length - 1}
                className={cn(
                  "absolute top-1/2 right-2 -translate-y-1/2 bg-black/30 text-white rounded-full p-1",
                  currentImageIndex === activity.media.length - 1 ? "opacity-30" : "opacity-70 hover:opacity-100",
                )}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </button>

              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
                {activity.media.map((_, index) => (
                  <div
                    key={index}
                    className={cn("w-2 h-2 rounded-full", index === currentImageIndex ? "bg-white" : "bg-white/50")}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="px-4 py-3 flex items-center justify-between border-t border-gray-100">
        <button
          className={cn("flex items-center text-sm", liked ? "text-red-500" : "text-gray-600")}
          onClick={handleLike}
        >
          <Heart className={cn("h-5 w-5 mr-1", liked && "fill-red-500")} />
          <span>{likeCount}</span>
        </button>

        <button className="flex items-center text-sm text-gray-600" onClick={() => setShowComments(!showComments)}>
          <MessageCircle className="h-5 w-5 mr-1" />
          <span>{activity.comments}</span>
        </button>

        <button className="flex items-center text-sm text-gray-600">
          <Share2 className="h-5 w-5 mr-1" />
          <span>Share</span>
        </button>
      </div>

      {/* Comments (simplified) */}
      {showComments && (
        <div className="px-4 py-3 border-t border-gray-100">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0"></div>
            <div className="ml-2 flex-1">
              <input
                type="text"
                placeholder="Add a comment..."
                className="w-full text-sm border border-gray-200 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
          </div>

          <div className="mt-3 text-sm text-gray-500 text-center">
            {activity.comments > 0 ? <p>View all {activity.comments} comments</p> : <p>No comments yet</p>}
          </div>
        </div>
      )}
    </div>
  )
}
