"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { getCountryEmoji, getCountryVibeEmoji } from "@/lib/country-utils"

interface CountryTooltipProps {
  country: string
  position: { x: number; y: number }
}

export function CountryTooltip({ country, position }: CountryTooltipProps) {
  const [emoji, setEmoji] = useState("")
  const [vibeEmoji, setVibeEmoji] = useState("")

  useEffect(() => {
    // Get country flag emoji
    setEmoji(getCountryEmoji(country))

    // Get a representative emoji for the country's vibe
    setVibeEmoji(getCountryVibeEmoji(country))
  }, [country])

  return (
    <motion.div
      className="absolute pointer-events-none z-10 px-3 py-2 rounded-md shadow-md text-sm font-medium bg-white text-gray-800 border border-gray-100"
      style={{
        left: `${position.x}px`,
        top: `${position.y - 10}px`,
        transformOrigin: "bottom center",
      }}
      initial={{ opacity: 0, scale: 0.8, y: -5 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.8, y: -5 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center space-x-2">
        <span>{emoji}</span>
        <span>{country}</span>
        <span>{vibeEmoji}</span>
      </div>
    </motion.div>
  )
}
