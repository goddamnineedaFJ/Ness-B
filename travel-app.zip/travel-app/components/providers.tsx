"use client"

import type { ReactNode } from "react"
import { MapDataProvider } from "@/context/map-data-context"

export function Providers({ children }: { children: ReactNode }) {
  return <MapDataProvider>{children}</MapDataProvider>
}
