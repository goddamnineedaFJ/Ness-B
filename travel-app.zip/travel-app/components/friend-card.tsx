"use client"

import { useState } from "react"
import Image from "next/image"
import { MessageSquare, User, Star } from "lucide-react"
import type { Friend } from "@/lib/mock-friends-data"
import { cn } from "@/lib/utils"

interface FriendCardProps {
  friend: Friend
  onToggleFavorite: (id: string) => void
}

export function FriendCard({ friend, onToggleFavorite }: FriendCardProps) {
  const [isFavorite, setIsFavorite] = useState(friend.isFavorite)

  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite)
    onToggleFavorite(friend.id)
  }

  return (
    <div className="relative flex flex-col items-center p-4 bg-white rounded-lg shadow-sm border border-gray-100 min-w-[150px] w-[150px]">
      <div
        className={cn("absolute top-2 right-2 cursor-pointer", isFavorite ? "text-yellow-400" : "text-gray-300")}
        onClick={handleToggleFavorite}
      >
        <Star className="h-5 w-5 fill-current" />
      </div>

      <div className="relative">
        <Image
          src={friend.avatar || "/placeholder.svg"}
          alt={friend.name}
          width={64}
          height={64}
          className="rounded-full object-cover"
        />
        <span
          className={cn(
            "absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white",
            friend.status === "online" ? "bg-green-500" : friend.status === "traveling" ? "bg-blue-500" : "bg-gray-400",
          )}
        />
      </div>

      <h3 className="mt-2 font-medium text-sm text-center line-clamp-1">{friend.name}</h3>
      <p className="text-xs text-gray-500 text-center">@{friend.username}</p>

      {friend.status === "traveling" && friend.location && (
        <div className="mt-1 text-xs text-blue-600 flex items-center">
          <span>{friend.location.emoji}</span>
          <span className="ml-1">{friend.location.name}</span>
        </div>
      )}

      {friend.status !== "traveling" && (
        <p className="mt-1 text-xs text-gray-500">{friend.status === "online" ? "Active now" : friend.lastActive}</p>
      )}

      <div className="flex mt-3 space-x-2">
        <button className="p-2 bg-primary/10 text-primary rounded-full">
          <MessageSquare className="h-4 w-4" />
        </button>
        <button className="p-2 bg-gray-100 text-gray-600 rounded-full">
          <User className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
