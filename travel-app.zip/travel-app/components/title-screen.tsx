"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import { useMapData } from "@/context/map-data-context"
import * as d3 from "d3"

export default function TitleScreen() {
  const router = useRouter()
  const { setMapData, isMapDataLoaded } = useMapData()
  const [loading, setLoading] = useState(true)
  const [isExiting, setIsExiting] = useState(false)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [loadingText, setLoadingText] = useState("Loading map data...")

  // Preload map data
  useEffect(() => {
    const preloadMapData = async () => {
      try {
        setLoadingText("Fetching world map...")
        setLoadingProgress(10)

        // Fetch world map data
        const response = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json")
        const worldData = await response.json()

        setLoadingText("Processing map data...")
        setLoadingProgress(50)

        // Fetch country names
        const namesResponse = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.tsv")
        const namesText = await namesResponse.text()
        const names = d3.tsvParse(namesText)

        setLoadingText("Finalizing...")
        setLoadingProgress(80)

        // Create a map of country IDs to names
        const countryNames = new Map()
        names.forEach((d: any) => {
          countryNames.set(d.iso_n3, d.name)
        })

        // Store the preloaded data
        setMapData({ worldData, countryNames })

        setLoadingProgress(100)
        setLoadingText("Ready to explore!")
        setLoading(false)
      } catch (error) {
        console.error("Error preloading map data:", error)
        setLoadingText("Failed to load map data. Please try again.")
        // Continue anyway after a delay
        setTimeout(() => setLoading(false), 1000)
      }
    }

    preloadMapData()
  }, [setMapData])

  const handleExplore = () => {
    setIsExiting(true)
    // Wait for exit animation to complete before navigating
    setTimeout(() => {
      router.push("/explore")
    }, 800) // Match this with the exit animation duration
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        className="relative h-screen w-full overflow-hidden bg-white"
        initial={{ opacity: 1 }}
        animate={{ opacity: isExiting ? 0 : 1 }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
      >
        {/* Content */}
        <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-black">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: isExiting ? 0 : 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
            className="text-center"
          >
            <motion.h1
              className="mb-2 font-sans text-6xl font-bold tracking-tight text-black sm:text-7xl md:text-8xl"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: isExiting ? 0 : 1, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut", delay: 0.4 }}
            >
              Pinvoy
            </motion.h1>

            <motion.p
              className="mb-8 text-xl font-light tracking-wide text-gray-600 sm:text-2xl"
              initial={{ opacity: 0 }}
              animate={{ opacity: isExiting ? 0 : 1 }}
              transition={{ duration: 0.8, ease: "easeOut", delay: 0.6 }}
            >
              Explore the world your way.
            </motion.p>
          </motion.div>

          {loading ? (
            <motion.div
              className="flex flex-col items-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: isExiting ? 0 : 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-64 h-2 bg-gray-200 rounded-full mb-2">
                <div
                  className="h-full bg-black rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${loadingProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500">{loadingText}</p>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: isExiting ? 0 : 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut", delay: 0.8 }}
            >
              <motion.button
                onClick={handleExplore}
                className="rounded-full bg-black px-8 py-3 font-medium text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 10px 25px rgba(0, 0, 0, 0.2)",
                }}
                whileTap={{ scale: 0.98 }}
                disabled={isExiting}
              >
                Explore Now
              </motion.button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
