"use client"

import { useEffect, useState } from "react"
import { getCountryEmoji } from "@/lib/country-utils"

interface MapTooltipProps {
  country: string
  position: { x: number; y: number }
  darkMode?: boolean
}

// Mock function to avoid errors. Replace with actual implementation if available.
const getCountryVibeEmoji = (country: string) => {
  // Replace this with your actual logic to determine the vibe emoji
  return "🌍"
}

export function MapTooltip({ country, position, darkMode = false }: MapTooltipProps) {
  const [emoji, setEmoji] = useState("")
  const [vibeEmoji, setVibeEmoji] = useState("")

  useEffect(() => {
    // Get country flag emoji
    setEmoji(getCountryEmoji(country))

    // Get a representative emoji for the country's vibe
    setVibeEmoji(getCountryVibeEmoji(country))
  }, [country])

  return (
    <div
      className={`absolute pointer-events-none z-10 px-3 py-2 rounded-md shadow-lg text-sm font-medium transform -translate-x-1/2 -translate-y-full transition-opacity duration-200 ease-in-out ${
        darkMode ? "bg-gray-800 text-white" : "bg-white text-gray-800"
      }`}
      style={{
        left: `${position.x}px`,
        top: `${position.y - 10}px`,
        opacity: 1,
        animation: "fadeIn 0.2s ease-in-out",
      }}
    >
      <div className="flex items-center space-x-1">
        <span>{emoji}</span>
        <span>{country}</span>
        <span>{vibeEmoji}</span>
      </div>
    </div>
  )
}
