"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  Utensils,
  Bed,
  Plane,
  Train,
  Bus,
  Share2,
  Edit,
  Download,
  Heart,
} from "lucide-react"
import { format } from "date-fns"

// Sample trip data
const tripDetails = {
  id: "trip-1",
  destination: "Tokyo, Japan",
  startDate: new Date("2023-10-15"),
  endDate: new Date("2023-10-25"),
  image: "/placeholder.svg?height=300&width=600",
  description:
    "Experience the perfect blend of traditional culture and futuristic technology in Tokyo, Japan's bustling capital.",
  budget: {
    total: 2500,
    accommodation: 800,
    transportation: 600,
    food: 500,
    activities: 400,
    other: 200,
  },
  itinerary: [
    {
      day: 1,
      date: new Date("2023-10-15"),
      activities: [
        {
          time: "09:00",
          title: "Arrival at Narita Airport",
          type: "transportation",
          icon: Plane,
        },
        {
          time: "12:00",
          title: "Check-in at Hotel Gracery Shinjuku",
          type: "accommodation",
          icon: Bed,
        },
        {
          time: "14:00",
          title: "Explore Shinjuku Gyoen National Garden",
          type: "activity",
          icon: MapPin,
        },
        {
          time: "18:00",
          title: "Dinner at Ichiran Ramen",
          type: "food",
          icon: Utensils,
        },
      ],
    },
    {
      day: 2,
      date: new Date("2023-10-16"),
      activities: [
        {
          time: "08:00",
          title: "Breakfast at hotel",
          type: "food",
          icon: Utensils,
        },
        {
          time: "10:00",
          title: "Visit Meiji Shrine",
          type: "activity",
          icon: MapPin,
        },
        {
          time: "13:00",
          title: "Lunch at Harajuku",
          type: "food",
          icon: Utensils,
        },
        {
          time: "15:00",
          title: "Shopping at Takeshita Street",
          type: "activity",
          icon: MapPin,
        },
        {
          time: "19:00",
          title: "Dinner at Gonpachi Nishi-Azabu",
          type: "food",
          icon: Utensils,
        },
      ],
    },
    {
      day: 3,
      date: new Date("2023-10-17"),
      activities: [
        {
          time: "09:00",
          title: "Visit Tokyo Skytree",
          type: "activity",
          icon: MapPin,
        },
        {
          time: "12:30",
          title: "Lunch at Asakusa",
          type: "food",
          icon: Utensils,
        },
        {
          time: "14:00",
          title: "Explore Senso-ji Temple",
          type: "activity",
          icon: MapPin,
        },
        {
          time: "17:00",
          title: "River cruise on the Sumida River",
          type: "activity",
          icon: MapPin,
        },
      ],
    },
  ],
}

export default function TripDetailPage() {
  const params = useParams()
  const [trip] = useState(tripDetails)
  const [liked, setLiked] = useState(false)

  return (
    <div className="container max-w-md mx-auto pb-20">
      <div className="relative h-64">
        <img src={trip.image || "/placeholder.svg"} alt={trip.destination} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />

        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center">
          <Link href="/my-trips">
            <Button variant="ghost" size="icon" className="bg-background/50 backdrop-blur-sm rounded-full">
              <ArrowLeft className="h-5 w-5 text-white" />
            </Button>
          </Link>

          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="bg-background/50 backdrop-blur-sm rounded-full"
              onClick={() => setLiked(!liked)}
            >
              <Heart className={`h-5 w-5 ${liked ? "text-red-500 fill-red-500" : "text-white"}`} />
            </Button>

            <Button variant="ghost" size="icon" className="bg-background/50 backdrop-blur-sm rounded-full">
              <Share2 className="h-5 w-5 text-white" />
            </Button>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 p-4">
          <h1 className="text-2xl font-bold text-white">{trip.destination}</h1>
          <div className="flex items-center text-sm text-white/80 mt-1">
            <Calendar className="h-4 w-4 mr-2" />
            <span>
              {format(trip.startDate, "MMM d")} - {format(trip.endDate, "MMM d, yyyy")}
            </span>
          </div>
        </div>
      </div>

      <div className="p-4">
        <p className="text-muted-foreground mb-4">{trip.description}</p>

        <div className="flex gap-2 mb-6">
          <Button variant="outline" size="sm" className="flex-1">
            <Edit className="h-4 w-4 mr-2" />
            Edit Trip
          </Button>
          <Button variant="outline" size="sm" className="flex-1">
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>

        <Tabs defaultValue="itinerary" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
            <TabsTrigger value="budget">Budget</TabsTrigger>
            <TabsTrigger value="info">Info</TabsTrigger>
          </TabsList>

          <TabsContent value="itinerary" className="space-y-6">
            {trip.itinerary.map((day) => (
              <Card key={day.day} className="overflow-hidden">
                <div className="bg-primary/10 p-3">
                  <h3 className="font-medium">
                    Day {day.day} - {format(day.date, "EEEE, MMM d")}
                  </h3>
                </div>

                <CardContent className="p-0">
                  {day.activities.map((activity, index) => (
                    <div key={index} className="flex items-start p-3 border-b last:border-b-0">
                      <div className="flex flex-col items-center mr-4">
                        <div className="text-sm font-medium">{activity.time}</div>
                        <div className="h-full w-px bg-border mt-2 mb-2"></div>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center">
                          <div
                            className={`
                            w-8 h-8 rounded-full flex items-center justify-center mr-2
                            ${activity.type === "food" ? "bg-orange-100 text-orange-600" : ""}
                            ${activity.type === "activity" ? "bg-blue-100 text-blue-600" : ""}
                            ${activity.type === "transportation" ? "bg-purple-100 text-purple-600" : ""}
                            ${activity.type === "accommodation" ? "bg-green-100 text-green-600" : ""}
                          `}
                          >
                            <activity.icon className="h-4 w-4" />
                          </div>
                          <div>
                            <h4 className="font-medium">{activity.title}</h4>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="budget">
            <Card>
              <CardContent className="p-4">
                <h3 className="text-lg font-medium mb-4">Budget Breakdown</h3>

                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b">
                    <span className="font-medium">Total Budget</span>
                    <span className="font-bold">${trip.budget.total}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Bed className="h-4 w-4 mr-2 text-green-500" />
                      <span>Accommodation</span>
                    </div>
                    <span>${trip.budget.accommodation}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Plane className="h-4 w-4 mr-2 text-purple-500" />
                      <span>Transportation</span>
                    </div>
                    <span>${trip.budget.transportation}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Utensils className="h-4 w-4 mr-2 text-orange-500" />
                      <span>Food</span>
                    </div>
                    <span>${trip.budget.food}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-blue-500" />
                      <span>Activities</span>
                    </div>
                    <span>${trip.budget.activities}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-500" />
                      <span>Other</span>
                    </div>
                    <span>${trip.budget.other}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="info">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">Transportation</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Plane className="h-4 w-4 mr-2 text-purple-500" />
                      <span>Flight: JL724 - Narita Airport (NRT)</span>
                    </div>
                    <div className="flex items-center">
                      <Train className="h-4 w-4 mr-2 text-purple-500" />
                      <span>Narita Express to Tokyo Station</span>
                    </div>
                    <div className="flex items-center">
                      <Bus className="h-4 w-4 mr-2 text-purple-500" />
                      <span>Tokyo Metro - 7-day pass</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Accommodation</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Bed className="h-4 w-4 mr-2 text-green-500" />
                      <span>Hotel Gracery Shinjuku</span>
                    </div>
                    <p className="text-sm text-muted-foreground pl-6">1-19-1 Kabukicho, Shinjuku-ku, Tokyo</p>
                    <p className="text-sm text-muted-foreground pl-6">Check-in: 3:00 PM, Check-out: 11:00 AM</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Important Information</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Emergency number: 110 (Police), 119 (Ambulance/Fire)</li>
                    <li>Japanese Embassy: +81-3-3224-5000</li>
                    <li>Time zone: Japan Standard Time (GMT+9)</li>
                    <li>Currency: Japanese Yen (¥)</li>
                    <li>Electricity: 100V, Type A/B plugs</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
