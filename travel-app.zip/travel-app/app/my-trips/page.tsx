"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Calendar, MapPin, Clock, Share2 } from "lucide-react"
import { format } from "date-fns"

interface Trip {
  id: string
  destination: string
  startDate: Date
  endDate: Date
  image: string
  status: "upcoming" | "past"
}

// Sample trip data
const sampleTrips: Trip[] = [
  {
    id: "trip-1",
    destination: "Tokyo, Japan",
    startDate: new Date("2023-10-15"),
    endDate: new Date("2023-10-25"),
    image: "/placeholder.svg?height=200&width=400",
    status: "upcoming",
  },
  {
    id: "trip-2",
    destination: "Paris, France",
    startDate: new Date("2023-08-05"),
    endDate: new Date("2023-08-12"),
    image: "/placeholder.svg?height=200&width=400",
    status: "past",
  },
  {
    id: "trip-3",
    destination: "Bali, Indonesia",
    startDate: new Date("2024-01-10"),
    endDate: new Date("2024-01-20"),
    image: "/placeholder.svg?height=200&width=400",
    status: "upcoming",
  },
  {
    id: "trip-4",
    destination: "New York, USA",
    startDate: new Date("2022-12-20"),
    endDate: new Date("2022-12-27"),
    image: "/placeholder.svg?height=200&width=400",
    status: "past",
  },
]

export default function MyTripsPage() {
  const [trips] = useState<Trip[]>(sampleTrips)

  const upcomingTrips = trips.filter((trip) => trip.status === "upcoming")
  const pastTrips = trips.filter((trip) => trip.status === "past")

  return (
    <div className="container max-w-md mx-auto py-6 px-4 pb-20">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">My Trips</h1>
        <Link href="/plan-trip">
          <Button size="sm" className="rounded-full">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Trip
          </Button>
        </Link>
      </header>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingTrips.length > 0 ? (
            upcomingTrips.map((trip) => <TripCard key={trip.id} trip={trip} />)
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No upcoming trips</p>
              <Link href="/plan-trip">
                <Button className="mt-4">Plan a Trip</Button>
              </Link>
            </div>
          )}
        </TabsContent>

        <TabsContent value="past" className="space-y-4">
          {pastTrips.length > 0 ? (
            pastTrips.map((trip) => <TripCard key={trip.id} trip={trip} />)
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No past trips</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface TripCardProps {
  trip: Trip
}

function TripCard({ trip }: TripCardProps) {
  return (
    <Link href={`/my-trips/${trip.id}`}>
      <Card className="overflow-hidden">
        <div className="relative h-40">
          <img src={trip.image || "/placeholder.svg"} alt={trip.destination} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 p-4">
            <h3 className="text-xl font-bold text-white">{trip.destination}</h3>
          </div>
        </div>

        <CardContent className="p-4">
          <div className="flex items-center text-sm text-muted-foreground mb-2">
            <Calendar className="h-4 w-4 mr-2" />
            <span>
              {format(trip.startDate, "MMM d")} - {format(trip.endDate, "MMM d, yyyy")}
            </span>
          </div>

          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="h-4 w-4 mr-2" />
            <span>{Math.ceil((trip.endDate.getTime() - trip.startDate.getTime()) / (1000 * 60 * 60 * 24))} days</span>
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0 flex justify-between">
          <Button variant="outline" size="sm">
            <MapPin className="h-4 w-4 mr-2" />
            View Itinerary
          </Button>

          <Button variant="ghost" size="icon">
            <Share2 className="h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </Link>
  )
}
