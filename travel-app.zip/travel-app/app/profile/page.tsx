"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Settings, MapPin, Globe, Camera, Grid, Bookmark, Heart } from "lucide-react"

// Sample user data
const userData = {
  name: "Alex Johnson",
  username: "alexj",
  bio: "Travel enthusiast | Photographer | 25 countries and counting ✈️",
  location: "New York, USA",
  avatar: "/placeholder.svg?height=100&width=100",
  coverPhoto: "/placeholder.svg?height=200&width=600",
  stats: {
    trips: 12,
    countries: 25,
    followers: 1243,
    following: 567,
  },
  posts: [
    {
      id: "post-1",
      image: "/placeholder.svg?height=150&width=150",
      location: "Paris, France",
    },
    {
      id: "post-2",
      image: "/placeholder.svg?height=150&width=150",
      location: "Rome, Italy",
    },
    {
      id: "post-3",
      image: "/placeholder.svg?height=150&width=150",
      location: "Barcelona, Spain",
    },
    {
      id: "post-4",
      image: "/placeholder.svg?height=150&width=150",
      location: "Tokyo, Japan",
    },
    {
      id: "post-5",
      image: "/placeholder.svg?height=150&width=150",
      location: "New York, USA",
    },
    {
      id: "post-6",
      image: "/placeholder.svg?height=150&width=150",
      location: "London, UK",
    },
  ],
  savedTrips: [
    {
      id: "trip-1",
      destination: "Tokyo, Japan",
      image: "/placeholder.svg?height=150&width=150",
      dates: "Oct 15-25, 2023",
    },
    {
      id: "trip-2",
      destination: "Paris, France",
      image: "/placeholder.svg?height=150&width=150",
      dates: "Aug 5-12, 2023",
    },
  ],
}

export default function ProfilePage() {
  const [user] = useState(userData)

  return (
    <div className="container max-w-md mx-auto pb-20">
      <div className="relative">
        <div className="h-32 bg-gradient-to-r from-blue-400 to-purple-500">
          <img src={user.coverPhoto || "/placeholder.svg"} alt="Cover" className="w-full h-full object-cover" />
        </div>

        <div className="absolute top-4 right-4">
          <Link href="/settings">
            <Button variant="ghost" size="icon" className="bg-background/50 backdrop-blur-sm rounded-full">
              <Settings className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        <div className="px-4 pb-4 relative">
          <Avatar className="h-20 w-20 border-4 border-background absolute -top-10">
            <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
          </Avatar>

          <div className="pt-12">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-xl font-bold">{user.name}</h1>
                <p className="text-sm text-muted-foreground">@{user.username}</p>
              </div>
              <Button>Edit Profile</Button>
            </div>

            <p className="mt-2">{user.bio}</p>

            <div className="flex items-center mt-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{user.location}</span>
            </div>

            <div className="flex justify-between mt-4 text-center">
              <div>
                <div className="font-bold">{user.stats.trips}</div>
                <div className="text-xs text-muted-foreground">Trips</div>
              </div>
              <div>
                <div className="font-bold">{user.stats.countries}</div>
                <div className="text-xs text-muted-foreground">Countries</div>
              </div>
              <div>
                <div className="font-bold">{user.stats.followers}</div>
                <div className="text-xs text-muted-foreground">Followers</div>
              </div>
              <div>
                <div className="font-bold">{user.stats.following}</div>
                <div className="text-xs text-muted-foreground">Following</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="posts" className="w-full px-4">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="posts">
            <Grid className="h-4 w-4 mr-2" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="trips">
            <Globe className="h-4 w-4 mr-2" />
            Trips
          </TabsTrigger>
          <TabsTrigger value="saved">
            <Bookmark className="h-4 w-4 mr-2" />
            Saved
          </TabsTrigger>
        </TabsList>

        <TabsContent value="posts">
          <div className="grid grid-cols-3 gap-1">
            {user.posts.map((post) => (
              <div key={post.id} className="relative aspect-square">
                <img
                  src={post.image || "/placeholder.svg"}
                  alt={post.location}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 hover:opacity-100">
                  <div className="text-white text-xs font-medium bg-black/50 px-2 py-1 rounded-full">
                    <MapPin className="h-3 w-3 inline mr-1" />
                    {post.location}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="trips">
          <div className="space-y-4">
            {user.savedTrips.map((trip) => (
              <Link href={`/my-trips/${trip.id}`} key={trip.id}>
                <Card className="overflow-hidden">
                  <div className="flex">
                    <div className="w-1/3">
                      <img
                        src={trip.image || "/placeholder.svg"}
                        alt={trip.destination}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-3 flex-1">
                      <h3 className="font-medium">{trip.destination}</h3>
                      <p className="text-xs text-muted-foreground">{trip.dates}</p>
                      <div className="flex items-center mt-2">
                        <Heart className="h-4 w-4 text-red-500 fill-red-500 mr-1" />
                        <span className="text-xs">254 likes</span>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              </Link>
            ))}

            <div className="text-center py-4">
              <Link href="/plan-trip">
                <Button>Plan a New Trip</Button>
              </Link>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="saved">
          <div className="text-center py-10">
            <Camera className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">No saved items yet</p>
            <Link href="/explore">
              <Button>Explore Destinations</Button>
            </Link>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
