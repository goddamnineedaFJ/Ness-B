"use client"

import { useState, useEffect } from "react"
import { ArrowDownCircle, Filter } from "lucide-react"
import { FeedItem } from "@/components/feed-item"
import { mockFeedItems } from "@/lib/mock-feed-data"

export default function FeedPage() {
  const [feedItems, setFeedItems] = useState(mockFeedItems)
  const [isLoading, setIsLoading] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Simulate loading feed items
  useEffect(() => {
    setIsLoading(true)
    // Simulate network request
    const timer = setTimeout(() => {
      setFeedItems(mockFeedItems)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)
    // Simulate network request
    setTimeout(() => {
      // Shuffle the feed items to simulate new content
      setFeedItems([...feedItems].sort(() => Math.random() - 0.5))
      setIsRefreshing(false)
    }, 1500)
  }

  if (isLoading) {
    return null // The loading.tsx file will be shown
  }

  return (
    <div className="container max-w-2xl mx-auto px-4 py-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">My Feed</h1>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center space-x-1 text-gray-600 hover:text-gray-900 disabled:opacity-50"
          >
            <ArrowDownCircle size={20} className={isRefreshing ? "animate-spin" : ""} />
            <span className="text-sm">{isRefreshing ? "Refreshing..." : "Refresh"}</span>
          </button>

          <button className="flex items-center space-x-1 text-gray-600 hover:text-gray-900">
            <Filter size={20} />
            <span className="text-sm">Filter</span>
          </button>
        </div>
      </div>

      {feedItems.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No trips in your feed yet.</p>
          <p className="text-gray-500">Follow travelers to see their adventures!</p>
        </div>
      ) : (
        <div>
          {feedItems.map((item) => (
            <FeedItem key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  )
}
