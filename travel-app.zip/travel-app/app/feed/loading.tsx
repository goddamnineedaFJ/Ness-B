import { Skeleton } from "@/components/ui/skeleton"

export default function FeedLoading() {
  return (
    <div className="container max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">My Feed</h1>

      {[1, 2, 3].map((item) => (
        <div key={item} className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
          {/* Header skeleton */}
          <div className="flex items-center p-4">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="ml-3 space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-24" />
            </div>
          </div>

          {/* Destination skeleton */}
          <div className="px-4 pb-3">
            <Skeleton className="h-5 w-48 mb-2" />
            <Skeleton className="h-3 w-36" />
          </div>

          {/* Description skeleton */}
          <div className="px-4 pb-4">
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-5/6 mb-2" />
            <Skeleton className="h-4 w-4/6" />
          </div>

          {/* Image skeleton */}
          <Skeleton className="h-64 w-full" />

          {/* Actions skeleton */}
          <div className="flex items-center justify-between p-4">
            <div className="flex space-x-4">
              <Skeleton className="h-6 w-16" />
              <Skeleton className="h-6 w-16" />
              <Skeleton className="h-6 w-8" />
            </div>
            <Skeleton className="h-6 w-6" />
          </div>
        </div>
      ))}
    </div>
  )
}
