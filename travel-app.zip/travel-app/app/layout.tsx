import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import MobileNavigation from "@/components/mobile-navigation"
import { Providers } from "@/components/providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Pinvoy - Travel App",
  description: "Explore the world your way",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          {children}
          <MobileNavigation />
        </Providers>
      </body>
    </html>
  )
}
