"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Moon, Bell, Globe, Lock, HelpCircle, LogOut, Smartphone } from "lucide-react"
import { useTheme } from "next-themes"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <div className="container max-w-md mx-auto py-6 px-4">
      <header className="flex items-center mb-6">
        <Link href="/profile" className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Settings</h1>
      </header>

      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-medium mb-4">Appearance</h2>
          <div className="bg-card rounded-lg divide-y">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <Moon className="h-5 w-5 mr-3" />
                <span>Dark Mode</span>
              </div>
              <Switch checked={theme === "dark"} onCheckedChange={toggleTheme} />
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-medium mb-4">Notifications</h2>
          <div className="bg-card rounded-lg divide-y">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <Bell className="h-5 w-5 mr-3" />
                <span>Push Notifications</span>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <Smartphone className="h-5 w-5 mr-3" />
                <span>Trip Alerts</span>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-medium mb-4">Account</h2>
          <div className="bg-card rounded-lg divide-y">
            <Link href="/settings/profile" className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <Globe className="h-5 w-5 mr-3" />
                <span>Edit Profile</span>
              </div>
              <ArrowLeft className="h-5 w-5 rotate-180" />
            </Link>
            <Link href="/settings/privacy" className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <Lock className="h-5 w-5 mr-3" />
                <span>Privacy & Security</span>
              </div>
              <ArrowLeft className="h-5 w-5 rotate-180" />
            </Link>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-medium mb-4">Support</h2>
          <div className="bg-card rounded-lg divide-y">
            <Link href="/help" className="flex items-center justify-between p-4">
              <div className="flex items-center">
                <HelpCircle className="h-5 w-5 mr-3" />
                <span>Help Center</span>
              </div>
              <ArrowLeft className="h-5 w-5 rotate-180" />
            </Link>
          </div>
        </div>

        <Button variant="destructive" className="w-full mt-8">
          <LogOut className="h-5 w-5 mr-2" />
          Log Out
        </Button>
      </div>
    </div>
  )
}
