"use client"

import { useState } from "react"
import WorldMap2D from "@/components/world-map-2d"

interface SocialUser {
  name: string
  username: string
  avatar: string
}

interface SocialPost {
  id: string
  user: SocialUser
  destination: string
  content: string
  image: string
  likes: number
  comments: number
  timestamp: string
}

interface TrendingDestination {
  id: string
  name: string
  image: string
  posts: number
}

// Sample social posts
const socialPosts: SocialPost[] = [
  {
    id: "post-1",
    user: {
      name: "Emma Wilson",
      username: "emmaw",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    destination: "Santorini, Greece",
    content: "The most breathtaking sunset I've ever seen! Santorini is truly magical. #Greece #IslandLife",
    image: "/placeholder.svg?height=300&width=500",
    likes: 243,
    comments: 42,
    timestamp: "2h ago",
  },
  {
    id: "post-2",
    user: {
      name: "Alex Chen",
      username: "alexc",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    destination: "Kyoto, Japan",
    content: "Exploring the ancient temples of Kyoto. The history and architecture here is incredible! #Japan #Travel",
    image: "/placeholder.svg?height=300&width=500",
    likes: 187,
    comments: 23,
    timestamp: "5h ago",
  },
  {
    id: "post-3",
    user: {
      name: "Sofia Rodriguez",
      username: "sofiar",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    destination: "Machu Picchu, Peru",
    content:
      "Finally made it to Machu Picchu! The hike was challenging but so worth it for these views. #BucketList #Peru",
    image: "/placeholder.svg?height=300&width=500",
    likes: 312,
    comments: 56,
    timestamp: "1d ago",
  },
]

// Sample trending destinations
const trendingDestinations: TrendingDestination[] = [
  {
    id: "dest-1",
    name: "Bali, Indonesia",
    image: "/placeholder.svg?height=150&width=150",
    posts: 12453,
  },
  {
    id: "dest-2",
    name: "Santorini, Greece",
    image: "/placeholder.svg?height=150&width=150",
    posts: 9872,
  },
  {
    id: "dest-3",
    name: "Tulum, Mexico",
    image: "/placeholder.svg?height=150&width=150",
    posts: 8765,
  },
  {
    id: "dest-4",
    name: "Kyoto, Japan",
    image: "/placeholder.svg?height=150&width=150",
    posts: 7654,
  },
]

export default function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [likedPosts, setLikedPosts] = useState<string[]>([])

  const toggleLike = (postId: string) => {
    setLikedPosts((prev) => (prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId]))
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      <main className="flex-1 flex flex-col items-center justify-center">
        <div className="w-full max-w-6xl h-[80vh] px-4">
          <WorldMap2D />
        </div>
      </main>
    </div>
  )
}
