"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Moon, Sun } from "lucide-react"
import WorldMap from "@/components/world-map"

export default function MapPage() {
  const [darkMode, setDarkMode] = useState(false)

  return (
    <div className="flex flex-col h-screen">
      <header className="p-4 flex justify-between items-center bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm fixed top-0 left-0 right-0 z-10 border-b">
        <h1 className="text-2xl font-bold">Pinvoy World Map</h1>
        <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)} aria-label="Toggle dark mode">
          {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </header>

      <main className="flex-1 pt-16 pb-16 relative">
        <div className="absolute inset-0">
          <WorldMap darkMode={darkMode} />
        </div>
      </main>

      <div className="fixed bottom-4 left-4 z-10 bg-white dark:bg-gray-800 p-3 rounded-md shadow-lg">
        <div className="text-sm">
          <p className="font-medium">Selected Countries: </p>
          <p className="text-xs text-muted-foreground mt-1">Click on countries to select them</p>
        </div>
      </div>
    </div>
  )
}
