"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, MapPin, Camera, Hotel, Utensils, Ticket, Info } from "lucide-react"

// Sample destination data
const destinationData = {
  "dest-1": {
    id: "dest-1",
    name: "Bali, Indonesia",
    description: "A tropical paradise known for its beautiful beaches, lush rice terraces, and vibrant culture.",
    image: "/placeholder.svg?height=300&width=600",
    attractions: [
      { name: "Ubud Monkey Forest", type: "nature", image: "/placeholder.svg?height=100&width=100" },
      { name: "Tanah Lot Temple", type: "culture", image: "/placeholder.svg?height=100&width=100" },
      { name: "Kuta Beach", type: "beach", image: "/placeholder.svg?height=100&width=100" },
      { name: "Tegallalang Rice Terraces", type: "nature", image: "/placeholder.svg?height=100&width=100" },
    ],
    hotels: [
      { name: "Four Seasons Resort Bali", price: "$$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "Padma Resort Ubud", price: "$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "Kuta Paradiso Hotel", price: "$$", image: "/placeholder.svg?height=100&width=100" },
    ],
    restaurants: [
      {
        name: "Warung Babi Guling Ibu Oka",
        cuisine: "Local",
        price: "$",
        image: "/placeholder.svg?height=100&width=100",
      },
      { name: "Merah Putih", cuisine: "Indonesian", price: "$$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "La Lucciola", cuisine: "Italian", price: "$$", image: "/placeholder.svg?height=100&width=100" },
    ],
    bestTimeToVisit: "April to October (dry season)",
    localCurrency: "Indonesian Rupiah (IDR)",
    language: "Indonesian (Bahasa Indonesia)",
  },
  "1": {
    id: "1",
    name: "Paris, France",
    description: "The City of Light, known for its art, fashion, gastronomy, and culture.",
    image: "/placeholder.svg?height=300&width=600",
    attractions: [
      { name: "Eiffel Tower", type: "landmark", image: "/placeholder.svg?height=100&width=100" },
      { name: "Louvre Museum", type: "culture", image: "/placeholder.svg?height=100&width=100" },
      { name: "Notre-Dame Cathedral", type: "landmark", image: "/placeholder.svg?height=100&width=100" },
      { name: "Montmartre", type: "neighborhood", image: "/placeholder.svg?height=100&width=100" },
    ],
    hotels: [
      { name: "Hôtel Plaza Athénée", price: "$$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "Hôtel de Crillon", price: "$$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "Citadines Tour Eiffel Paris", price: "$$", image: "/placeholder.svg?height=100&width=100" },
    ],
    restaurants: [
      { name: "Le Jules Verne", cuisine: "French", price: "$$$", image: "/placeholder.svg?height=100&width=100" },
      { name: "Bistrot Paul Bert", cuisine: "French", price: "$$", image: "/placeholder.svg?height=100&width=100" },
      {
        name: "L'As du Fallafel",
        cuisine: "Middle Eastern",
        price: "$",
        image: "/placeholder.svg?height=100&width=100",
      },
    ],
    bestTimeToVisit: "April to June, September to October",
    localCurrency: "Euro (EUR)",
    language: "French",
  },
}

export default function DestinationPage() {
  const params = useParams()
  const id = typeof params.id === "string" ? params.id : "1"
  const [destination] = useState(destinationData[id] || destinationData["1"])

  return (
    <div className="container max-w-md mx-auto pb-20">
      <div className="relative h-64">
        <img
          src={destination.image || "/placeholder.svg"}
          alt={destination.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />

        <div className="absolute top-0 left-0 right-0 p-4">
          <Link href="/">
            <Button variant="ghost" size="icon" className="bg-background/50 backdrop-blur-sm rounded-full">
              <ArrowLeft className="h-5 w-5 text-white" />
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 p-4">
          <h1 className="text-2xl font-bold text-white">{destination.name}</h1>
        </div>
      </div>

      <div className="p-4">
        <p className="text-muted-foreground mb-6">{destination.description}</p>

        <div className="flex gap-2 mb-6">
          <Button className="flex-1">
            <Camera className="h-4 w-4 mr-2" />
            View Gallery
          </Button>
          <Link href="/plan-trip" className="flex-1">
            <Button variant="outline" className="w-full">
              <MapPin className="h-4 w-4 mr-2" />
              Plan Trip Here
            </Button>
          </Link>
        </div>

        <Tabs defaultValue="attractions" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="attractions">
              <Camera className="h-4 w-4 mb-1" />
              <span className="text-xs">See</span>
            </TabsTrigger>
            <TabsTrigger value="hotels">
              <Hotel className="h-4 w-4 mb-1" />
              <span className="text-xs">Stay</span>
            </TabsTrigger>
            <TabsTrigger value="restaurants">
              <Utensils className="h-4 w-4 mb-1" />
              <span className="text-xs">Eat</span>
            </TabsTrigger>
            <TabsTrigger value="info">
              <Info className="h-4 w-4 mb-1" />
              <span className="text-xs">Info</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="attractions" className="space-y-4">
            {destination.attractions.map((attraction, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="flex">
                  <div className="w-1/3">
                    <img
                      src={attraction.image || "/placeholder.svg"}
                      alt={attraction.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-3 flex-1">
                    <h3 className="font-medium">{attraction.name}</h3>
                    <p className="text-xs text-muted-foreground">{attraction.type}</p>
                    <div className="flex items-center mt-2">
                      <Ticket className="h-4 w-4 text-primary mr-1" />
                      <span className="text-xs">Book tickets</span>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="hotels" className="space-y-4">
            {destination.hotels.map((hotel, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="flex">
                  <div className="w-1/3">
                    <img
                      src={hotel.image || "/placeholder.svg"}
                      alt={hotel.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-3 flex-1">
                    <h3 className="font-medium">{hotel.name}</h3>
                    <p className="text-xs text-muted-foreground">{hotel.price}</p>
                    <div className="flex items-center mt-2">
                      <Hotel className="h-4 w-4 text-primary mr-1" />
                      <span className="text-xs">Check availability</span>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="restaurants" className="space-y-4">
            {destination.restaurants.map((restaurant, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="flex">
                  <div className="w-1/3">
                    <img
                      src={restaurant.image || "/placeholder.svg"}
                      alt={restaurant.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-3 flex-1">
                    <h3 className="font-medium">{restaurant.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {restaurant.cuisine} · {restaurant.price}
                    </p>
                    <div className="flex items-center mt-2">
                      <Utensils className="h-4 w-4 text-primary mr-1" />
                      <span className="text-xs">View menu</span>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="info">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Best Time to Visit</h3>
                  <p className="text-sm">{destination.bestTimeToVisit}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Local Currency</h3>
                  <p className="text-sm">{destination.localCurrency}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Language</h3>
                  <p className="text-sm">{destination.language}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Travel Tips</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Always carry a copy of your passport</li>
                    <li>Check visa requirements before traveling</li>
                    <li>Get travel insurance</li>
                    <li>Learn a few basic phrases in the local language</li>
                    <li>Respect local customs and traditions</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
