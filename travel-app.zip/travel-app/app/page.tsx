"use client"

import TitleScreen from "@/components/title-screen"

export default function HomePage() {
  return <TitleScreen />
}
