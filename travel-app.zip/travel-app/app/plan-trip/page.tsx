"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, CalendarIcon, Loader2 } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { generateTripPlan } from "@/lib/ai-trip-planner"
import Link from "next/link"
import * as d3 from "d3"

interface TripFormData {
  destination: string
  startDate: Date | null
  endDate: Date | null
  budget: number
  interests: string[]
  additionalInfo: string
  travelers: string
}

export default function PlanTripPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [countryName, setCountryName] = useState<string>("")
  const [formData, setFormData] = useState<TripFormData>({
    destination: "",
    startDate: null,
    endDate: null,
    budget: 50,
    interests: [],
    additionalInfo: "",
    travelers: "1",
  })

  // Get country ID from URL parameters
  const countryId = searchParams.get("country")

  // Fetch country name if ID is provided
  useEffect(() => {
    if (countryId) {
      const fetchCountryName = async () => {
        try {
          // Fetch country names
          const namesResponse = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.tsv")
          const namesText = await namesResponse.text()
          const names = d3.tsvParse(namesText)

          // Find country by ID
          const country = names.find((d: any) => d.iso_n3 === countryId)

          if (country) {
            const name = country.name
            setCountryName(name)
            setFormData((prev) => ({ ...prev, destination: name }))
          }
        } catch (error) {
          console.error("Error fetching country name:", error)
        }
      }

      fetchCountryName()
    }
  }, [countryId])

  const interestOptions = [
    "Beaches",
    "Mountains",
    "Food",
    "Culture",
    "History",
    "Adventure",
    "Relaxation",
    "Nightlife",
    "Shopping",
    "Nature",
  ]

  const handleInterestToggle = (interest: string) => {
    setFormData((prev) => {
      if (prev.interests.includes(interest)) {
        return {
          ...prev,
          interests: prev.interests.filter((i) => i !== interest),
        }
      } else {
        return {
          ...prev,
          interests: [...prev.interests, interest],
        }
      }
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.destination || !formData.startDate || !formData.endDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      // In a real app, this would call an API endpoint
      const tripPlan = await generateTripPlan(formData)

      // Navigate to the generated trip plan
      router.push(`/my-trips/${tripPlan.id}`)

      toast({
        title: "Trip plan generated!",
        description: "Your personalized itinerary is ready to view",
      })
    } catch (error) {
      toast({
        title: "Error generating trip plan",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="container max-w-md mx-auto py-6 px-4">
      <header className="flex items-center mb-6">
        <Link href={countryId ? `/country/${countryId}` : "/"} className="mr-4">
          <ArrowLeft className="h-6 w-6" />
        </Link>
        <h1 className="text-2xl font-bold">Plan Your Trip{countryName ? ` to ${countryName}` : ""}</h1>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Where do you want to go?</label>
          <Input
            placeholder="City, country, or region"
            value={formData.destination}
            onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Start Date</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.startDate && "text-muted-foreground",
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.startDate ? format(formData.startDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={formData.startDate}
                  onSelect={(date) => setFormData({ ...formData, startDate: date })}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">End Date</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.endDate && "text-muted-foreground",
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.endDate ? format(formData.endDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={formData.endDate}
                  onSelect={(date) => setFormData({ ...formData, endDate: date })}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Number of Travelers</label>
          <Select value={formData.travelers} onValueChange={(value) => setFormData({ ...formData, travelers: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select number of travelers" />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} {num === 1 ? "person" : "people"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Budget Level</label>
          <div className="flex items-center space-x-2">
            <span className="text-xs">Budget</span>
            <Slider
              value={[formData.budget]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => setFormData({ ...formData, budget: value[0] })}
              className="flex-1"
            />
            <span className="text-xs">Luxury</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Interests</label>
          <div className="flex flex-wrap gap-2">
            {interestOptions.map((interest) => (
              <Button
                key={interest}
                type="button"
                variant={formData.interests.includes(interest) ? "default" : "outline"}
                size="sm"
                onClick={() => handleInterestToggle(interest)}
                className="rounded-full"
              >
                {interest}
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Additional Information</label>
          <Textarea
            placeholder="Any specific requirements or preferences?"
            value={formData.additionalInfo}
            onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
            className="min-h-[100px]"
          />
        </div>

        <Button type="submit" className="w-full" disabled={isGenerating}>
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating your trip plan...
            </>
          ) : (
            "Generate AI Trip Plan"
          )}
        </Button>
      </form>
    </div>
  )
}
