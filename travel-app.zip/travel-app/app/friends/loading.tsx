import { Skeleton } from "@/components/ui/skeleton"

export default function FriendsLoading() {
  return (
    <div className="container max-w-lg mx-auto px-4 pb-24 pt-4">
      <h1 className="text-2xl font-bold mb-4">Friends</h1>

      {/* Friends list skeleton */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-6 w-20" />
        </div>

        <div className="flex space-x-4 overflow-x-auto pb-4">
          {Array(5)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="flex flex-col items-center space-y-2 min-w-[150px]">
                <Skeleton className="h-16 w-16 rounded-full" />
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-3 w-16" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Activity feed skeleton */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-6 w-20" />
        </div>

        {Array(3)
          .fill(0)
          .map((_, i) => (
            <div key={i} className="mb-4 bg-white rounded-lg shadow-sm border border-gray-100 p-4">
              <div className="flex items-center mb-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="ml-3 flex-1">
                  <Skeleton className="h-4 w-24 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
                <Skeleton className="h-4 w-16" />
              </div>
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4 mb-4" />
              <Skeleton className="h-48 w-full mb-4" />
              <div className="flex justify-between">
                <Skeleton className="h-6 w-16" />
                <Skeleton className="h-6 w-16" />
                <Skeleton className="h-6 w-16" />
              </div>
            </div>
          ))}
      </div>
    </div>
  )
}
