"use client"

import { useState, useEffect } from "react"
import { Search, Filter, Plus, ChevronRight } from "lucide-react"
import { mockFriends, type Friend } from "@/lib/mock-friends-data"
import { FriendCard } from "@/components/friend-card"
import { FriendActivity } from "@/components/friend-activity"

export default function FriendsPage() {
  const [friends, setFriends] = useState<Friend[]>([])
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState<"all" | "favorites" | "online" | "traveling">("all")

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setFriends(mockFriends)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleToggleFavorite = (id: string) => {
    setFriends(friends.map((friend) => (friend.id === id ? { ...friend, isFavorite: !friend.isFavorite } : friend)))
  }

  const filteredFriends = () => {
    switch (activeFilter) {
      case "favorites":
        return friends.filter((friend) => friend.isFavorite)
      case "online":
        return friends.filter((friend) => friend.status === "online")
      case "traveling":
        return friends.filter((friend) => friend.status === "traveling")
      default:
        return friends
    }
  }

  // Get all activities from all friends, sorted by timestamp
  const allActivities = friends
    .flatMap((friend) =>
      friend.activities.map((activity) => ({
        ...activity,
        friendId: friend.id,
        friendName: friend.name,
        friendUsername: friend.username,
        friendAvatar: friend.avatar,
      })),
    )
    .sort((a, b) => {
      // Simple sort by recency (this is just for demo purposes)
      if (a.timestamp.includes("now") || a.timestamp.includes("minute")) return -1
      if (b.timestamp.includes("now") || b.timestamp.includes("minute")) return 1
      if (a.timestamp.includes("hour") && !b.timestamp.includes("hour")) return -1
      if (b.timestamp.includes("hour") && !a.timestamp.includes("hour")) return 1
      return 0
    })

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>
  }

  return (
    <div className="container max-w-lg mx-auto px-4 pb-24 pt-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Friends</h1>
        <div className="flex space-x-2">
          <button className="p-2 rounded-full bg-gray-100">
            <Search className="h-5 w-5 text-gray-600" />
          </button>
          <button className="p-2 rounded-full bg-gray-100">
            <Filter className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Friends list */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <div className="flex space-x-3">
            <button
              className={`text-sm font-medium ${activeFilter === "all" ? "text-primary" : "text-gray-500"}`}
              onClick={() => setActiveFilter("all")}
            >
              All
            </button>
            <button
              className={`text-sm font-medium ${activeFilter === "favorites" ? "text-primary" : "text-gray-500"}`}
              onClick={() => setActiveFilter("favorites")}
            >
              Favorites
            </button>
            <button
              className={`text-sm font-medium ${activeFilter === "online" ? "text-primary" : "text-gray-500"}`}
              onClick={() => setActiveFilter("online")}
            >
              Online
            </button>
            <button
              className={`text-sm font-medium ${activeFilter === "traveling" ? "text-primary" : "text-gray-500"}`}
              onClick={() => setActiveFilter("traveling")}
            >
              Traveling
            </button>
          </div>
          <button className="text-sm text-primary font-medium flex items-center">
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </button>
        </div>

        <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide">
          <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg border border-dashed border-gray-200 min-w-[150px] w-[150px]">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-2">
              <Plus className="h-6 w-6 text-gray-400" />
            </div>
            <p className="text-sm text-gray-500">Add Friend</p>
          </div>

          {filteredFriends().map((friend) => (
            <FriendCard key={friend.id} friend={friend} onToggleFavorite={handleToggleFavorite} />
          ))}
        </div>
      </div>

      {/* Activity feed */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">Recent Activities</h2>
          <button className="text-sm text-primary font-medium">Refresh</button>
        </div>

        {allActivities.length > 0 ? (
          allActivities.map((activity) => (
            <FriendActivity
              key={activity.id}
              activity={activity}
              friendName={activity.friendName}
              friendUsername={activity.friendUsername}
              friendAvatar={activity.friendAvatar}
            />
          ))
        ) : (
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 text-center">
            <p className="text-gray-500">No recent activities from your friends.</p>
            <button className="mt-3 text-sm text-primary font-medium">Find more friends</button>
          </div>
        )}
      </div>
    </div>
  )
}
