"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MapPin, Calendar, Plane } from "lucide-react"
import { getCountryEmoji, getCountryVibeEmoji } from "@/lib/country-utils"
import { motion } from "framer-motion"
import * as d3 from "d3"

// Sample country descriptions
const countryDescriptions: Record<string, string> = {
  "840":
    "The United States is a diverse country with bustling cities, stunning national parks, and a rich cultural heritage. From the beaches of California to the skyscrapers of New York, there's something for every traveler.",
  "250":
    "France is known for its art, culture, and gastronomy. Visit the iconic Eiffel Tower in Paris, explore the beautiful countryside, or indulge in world-class cuisine and wine.",
  "392":
    "Japan blends ancient traditions with cutting-edge technology. Experience the bustling streets of Tokyo, the serene temples of Kyoto, and the natural beauty of Mount Fuji.",
  "380":
    "Italy offers a perfect mix of history, art, and culinary delights. Explore ancient ruins in Rome, Renaissance art in Florence, and enjoy authentic pizza and pasta throughout the country.",
  "724":
    "Spain captivates visitors with its vibrant culture, stunning architecture, and beautiful beaches. Experience flamenco dancing in Seville, Gaudí's masterpieces in Barcelona, and relax on the Costa del Sol.",
  // Add more countries as needed
}

export default function CountryPage() {
  const router = useRouter()
  const params = useParams()
  const countryId = params.id as string

  const [countryName, setCountryName] = useState<string>("")
  const [countryEmoji, setCountryEmoji] = useState<string>("")
  const [countryVibeEmoji, setCountryVibeEmoji] = useState<string>("")
  const [description, setDescription] = useState<string>("")
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const fetchCountryData = async () => {
      try {
        // Fetch country names
        const namesResponse = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.tsv")
        const namesText = await namesResponse.text()
        const names = d3.tsvParse(namesText)

        // Find country by ID
        const country = names.find((d: any) => d.iso_n3 === countryId)

        if (country) {
          const name = country.name
          setCountryName(name)
          setCountryEmoji(getCountryEmoji(name))
          setCountryVibeEmoji(getCountryVibeEmoji(name))

          // Get description or use a default
          setDescription(
            countryDescriptions[countryId] ||
              `${name} is a wonderful destination waiting to be explored. Plan your trip to discover its unique culture, attractions, and experiences.`,
          )
        } else {
          // Handle country not found
          setCountryName("Unknown Country")
          setDescription("Country information not available.")
        }

        setLoading(false)
      } catch (error) {
        console.error("Error fetching country data:", error)
        setLoading(false)
      }
    }

    fetchCountryData()
  }, [countryId])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Link href="/" className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Map
      </Link>

      <motion.div
        className="bg-white rounded-lg shadow-md overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="p-6">
          <div className="flex items-center mb-4">
            <span className="text-4xl mr-3">{countryEmoji}</span>
            <h1 className="text-3xl font-bold">{countryName}</h1>
            <span className="text-3xl ml-3">{countryVibeEmoji}</span>
          </div>

          <p className="text-gray-700 mb-6">{description}</p>

          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <h2 className="text-xl font-semibold mb-3 flex items-center">
              <MapPin className="mr-2 h-5 w-5 text-red-500" />
              Popular Destinations
            </h2>
            <ul className="space-y-2">
              {/* These would be dynamically generated in a real app */}
              <li className="text-gray-700">Major City 1</li>
              <li className="text-gray-700">Major City 2</li>
              <li className="text-gray-700">Major City 3</li>
            </ul>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <h2 className="text-xl font-semibold mb-3 flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-blue-500" />
              Best Time to Visit
            </h2>
            <p className="text-gray-700">Spring (March to May) and Fall (September to November)</p>
          </div>

          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">Plan Your Trip</h2>
            <Button
              size="lg"
              className="w-full flex items-center justify-center"
              onClick={() => router.push(`/plan-trip?country=${countryId}`)}
            >
              <Plane className="mr-2 h-5 w-5" />
              Create AI Trip Plan
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
