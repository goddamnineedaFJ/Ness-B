export interface FeedUser {
  id: string
  name: string
  username: string
  avatar: string
}

export interface FeedComment {
  id: string
  user: FeedUser
  text: string
  timestamp: string
}

export interface FeedItem {
  id: string
  user: FeedUser
  destination: string
  countryCode: string
  startDate: string
  endDate: string
  duration: number
  description: string
  images: string[]
  likes: number
  comments: FeedComment[]
  isLiked: boolean
  isSaved: boolean
  timestamp: string
}

export const mockUsers: FeedUser[] = [
  {
    id: "user1",
    name: "Emma Wilson",
    username: "emmawilson",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "user2",
    name: "James Rodriguez",
    username: "jamesrod",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "user3",
    name: "Sophia Chen",
    username: "sophiachen",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "user4",
    name: "Michael Johnson",
    username: "mikej",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "user5",
    name: "Olivia Davis",
    username: "oliviad",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export const mockFeedItems: FeedItem[] = [
  {
    id: "trip1",
    user: mockUsers[0],
    destination: "Tokyo, Japan",
    countryCode: "JP",
    startDate: "2023-10-15",
    endDate: "2023-10-25",
    duration: 10,
    description:
      "Exploring the vibrant streets of Tokyo! From the serene temples to the bustling Shibuya crossing, this city never fails to amaze me. The food is incredible - had the best ramen of my life last night! 🍜",
    images: [
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
    ],
    likes: 124,
    comments: [
      {
        id: "comment1",
        user: mockUsers[1],
        text: "The food looks amazing! I'm planning to visit next year.",
        timestamp: "2023-10-26T14:30:00Z",
      },
      {
        id: "comment2",
        user: mockUsers[2],
        text: "Which temple was your favorite?",
        timestamp: "2023-10-26T15:45:00Z",
      },
    ],
    isLiked: true,
    isSaved: false,
    timestamp: "2023-10-26T12:00:00Z",
  },
  {
    id: "trip2",
    user: mockUsers[1],
    destination: "Barcelona, Spain",
    countryCode: "ES",
    startDate: "2023-09-05",
    endDate: "2023-09-12",
    duration: 7,
    description:
      "Barcelona has stolen my heart! Gaudi's architecture is mind-blowing, especially La Sagrada Familia. Spent hours wandering through the Gothic Quarter and enjoying tapas at local spots. 🇪🇸",
    images: ["/placeholder.svg?height=300&width=500", "/placeholder.svg?height=300&width=500"],
    likes: 89,
    comments: [
      {
        id: "comment3",
        user: mockUsers[0],
        text: "I love Barcelona! Did you visit Park Güell?",
        timestamp: "2023-09-14T10:20:00Z",
      },
    ],
    isLiked: false,
    isSaved: true,
    timestamp: "2023-09-13T18:30:00Z",
  },
  {
    id: "trip3",
    user: mockUsers[2],
    destination: "Bali, Indonesia",
    countryCode: "ID",
    startDate: "2023-08-10",
    endDate: "2023-08-24",
    duration: 14,
    description:
      "Two weeks in paradise! Bali has been the perfect mix of adventure and relaxation. Hiked up Mount Batur for sunrise, explored rice terraces, and spent days lounging on beautiful beaches. 🌴",
    images: [
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
    ],
    likes: 215,
    comments: [
      {
        id: "comment4",
        user: mockUsers[3],
        text: "Bali is on my bucket list! Any tips for first-timers?",
        timestamp: "2023-08-25T09:15:00Z",
      },
      {
        id: "comment5",
        user: mockUsers[4],
        text: "Those beaches look incredible! Which was your favorite?",
        timestamp: "2023-08-25T11:30:00Z",
      },
      {
        id: "comment6",
        user: mockUsers[0],
        text: "How was the food? I've heard amazing things!",
        timestamp: "2023-08-26T14:00:00Z",
      },
    ],
    isLiked: true,
    isSaved: true,
    timestamp: "2023-08-25T08:00:00Z",
  },
  {
    id: "trip4",
    user: mockUsers[3],
    destination: "New York City, USA",
    countryCode: "US",
    startDate: "2023-11-01",
    endDate: "2023-11-05",
    duration: 4,
    description:
      "Quick weekend trip to the Big Apple! Caught a Broadway show, walked through Central Park, and ate way too much pizza. The city that never sleeps definitely lives up to its name! 🗽",
    images: ["/placeholder.svg?height=300&width=500", "/placeholder.svg?height=300&width=500"],
    likes: 67,
    comments: [],
    isLiked: false,
    isSaved: false,
    timestamp: "2023-11-06T20:45:00Z",
  },
  {
    id: "trip5",
    user: mockUsers[4],
    destination: "Santorini, Greece",
    countryCode: "GR",
    startDate: "2023-07-20",
    endDate: "2023-07-30",
    duration: 10,
    description:
      "Santorini is even more beautiful than in the photos! Those iconic white buildings with blue domes against the backdrop of the Aegean Sea are simply breathtaking. Watched the most incredible sunset in Oia. 🇬🇷",
    images: [
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
      "/placeholder.svg?height=300&width=500",
    ],
    likes: 178,
    comments: [
      {
        id: "comment7",
        user: mockUsers[2],
        text: "This looks like a dream! Did you stay in Oia?",
        timestamp: "2023-07-31T16:20:00Z",
      },
    ],
    isLiked: true,
    isSaved: false,
    timestamp: "2023-07-31T15:00:00Z",
  },
]
