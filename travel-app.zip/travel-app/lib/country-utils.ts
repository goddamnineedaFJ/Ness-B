// Map of country names to ISO codes (partial list)
const countryCodeMap: Record<string, string> = {
  Afghanistan: "AF",
  Albania: "AL",
  Algeria: "DZ",
  Argentina: "AR",
  Australia: "AU",
  Austria: "AT",
  Brazil: "BR",
  Canada: "CA",
  China: "CN",
  Egypt: "EG",
  France: "FR",
  Germany: "DE",
  Greece: "GR",
  India: "IN",
  Indonesia: "ID",
  Italy: "IT",
  Japan: "JP",
  Mexico: "MX",
  Morocco: "MA",
  Netherlands: "NL",
  "New Zealand": "NZ",
  Peru: "PE",
  Russia: "RU",
  "South Africa": "ZA",
  Spain: "ES",
  Sweden: "SE",
  Thailand: "TH",
  Turkey: "TR",
  "United Kingdom": "GB",
  "United States": "US",
  // Add more countries as needed
}

// Map of country names to representative emojis
const countryVibeMap: Record<string, string> = {
  Afghanistan: "🏔️",
  Albania: "🏛️",
  Algeria: "🏜️",
  Argentina: "🧉",
  Australia: "🦘",
  Austria: "⛰️",
  Brazil: "🎉",
  Canada: "🍁",
  China: "🏮",
  Egypt: "🔺",
  France: "🥐",
  Germany: "🍺",
  Greece: "🏛️",
  India: "🕌",
  Indonesia: "🏝️",
  Italy: "🍕",
  Japan: "🍣",
  Mexico: "🌮",
  Morocco: "🕌",
  Netherlands: "🌷",
  "New Zealand": "🥝",
  Peru: "🏔️",
  Russia: "❄️",
  "South Africa": "🦁",
  Spain: "💃",
  Sweden: "🌲",
  Thailand: "🏝️",
  Turkey: "🧿",
  "United Kingdom": "☕",
  "United States": "🗽",
  // Add more countries as needed
}

// Get country flag emoji from country name
export function getCountryEmoji(countryName: string): string {
  const code = countryCodeMap[countryName]
  if (!code) return "🏳️"

  // Convert ISO code to regional indicator symbols (flag emoji)
  return code
    .toUpperCase()
    .split("")
    .map((char) => String.fromCodePoint(char.charCodeAt(0) + 127397))
    .join("")
}

// Get representative emoji for a country
export function getCountryVibeEmoji(countryName: string): string {
  return countryVibeMap[countryName] || "✈️"
}
