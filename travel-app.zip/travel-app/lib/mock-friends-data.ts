export interface FriendActivity {
  id: string
  type: "trip" | "photo" | "review" | "check-in" | "achievement" | "booking"
  content: string
  timestamp: string
  location?: {
    name: string
    country: string
    emoji: string
  }
  likes: number
  comments: number
  media?: {
    type: "image" | "video"
    url: string
  }[]
  liked?: boolean
}

export interface Friend {
  id: string
  name: string
  username: string
  avatar: string
  status: "online" | "offline" | "traveling"
  location?: {
    name: string
    country: string
    emoji: string
  }
  lastActive: string
  activities: FriendActivity[]
  isFavorite: boolean
}

export const mockFriends: Friend[] = [
  {
    id: "1",
    name: "Emma Johnson",
    username: "emma_travels",
    avatar: "/placeholder.svg?height=100&width=100",
    status: "traveling",
    location: {
      name: "Barcelona",
      country: "Spain",
      emoji: "🇪🇸",
    },
    lastActive: "2 minutes ago",
    isFavorite: true,
    activities: [
      {
        id: "a1",
        type: "check-in",
        content: "Just arrived in Barcelona! The architecture is amazing! 😍",
        timestamp: "2 hours ago",
        location: {
          name: "Barcelona",
          country: "Spain",
          emoji: "🇪🇸",
        },
        likes: 24,
        comments: 5,
        media: [
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
        ],
        liked: true,
      },
      {
        id: "a2",
        type: "booking",
        content: "Just booked my flight to Rome for next month! Anyone have recommendations?",
        timestamp: "2 days ago",
        location: {
          name: "Rome",
          country: "Italy",
          emoji: "🇮🇹",
        },
        likes: 18,
        comments: 12,
      },
    ],
  },
  {
    id: "2",
    name: "Michael Chen",
    username: "mike_explores",
    avatar: "/placeholder.svg?height=100&width=100",
    status: "online",
    lastActive: "Active now",
    isFavorite: false,
    activities: [
      {
        id: "a3",
        type: "photo",
        content: "Sunset over the mountains in Switzerland. One of the most beautiful views I've ever seen.",
        timestamp: "5 hours ago",
        location: {
          name: "Interlaken",
          country: "Switzerland",
          emoji: "🇨🇭",
        },
        likes: 42,
        comments: 7,
        media: [
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
        ],
      },
    ],
  },
  {
    id: "3",
    name: "Sophia Rodriguez",
    username: "sophia_wanders",
    avatar: "/placeholder.svg?height=100&width=100",
    status: "offline",
    lastActive: "3 hours ago",
    isFavorite: true,
    activities: [
      {
        id: "a4",
        type: "review",
        content:
          "This little café in Paris has the best croissants I've ever tasted! Highly recommend visiting \"Le Petit Parisien\" if you're in the area.",
        timestamp: "1 day ago",
        location: {
          name: "Paris",
          country: "France",
          emoji: "🇫🇷",
        },
        likes: 31,
        comments: 9,
        media: [
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
        ],
      },
      {
        id: "a5",
        type: "achievement",
        content: "Just visited my 30th country! 🎉",
        timestamp: "3 days ago",
        likes: 56,
        comments: 14,
      },
    ],
  },
  {
    id: "4",
    name: "James Wilson",
    username: "james_backpacker",
    avatar: "/placeholder.svg?height=100&width=100",
    status: "traveling",
    location: {
      name: "Tokyo",
      country: "Japan",
      emoji: "🇯🇵",
    },
    lastActive: "1 hour ago",
    isFavorite: false,
    activities: [
      {
        id: "a6",
        type: "trip",
        content: "Starting my 2-week journey across Japan! First stop: Tokyo",
        timestamp: "1 day ago",
        location: {
          name: "Tokyo",
          country: "Japan",
          emoji: "🇯🇵",
        },
        likes: 38,
        comments: 11,
        media: [
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
        ],
      },
    ],
  },
  {
    id: "5",
    name: "Olivia Kim",
    username: "liv_travels",
    avatar: "/placeholder.svg?height=100&width=100",
    status: "online",
    lastActive: "Active now",
    isFavorite: true,
    activities: [
      {
        id: "a7",
        type: "photo",
        content: "Island hopping in Greece was the highlight of my summer!",
        timestamp: "4 hours ago",
        location: {
          name: "Santorini",
          country: "Greece",
          emoji: "🇬🇷",
        },
        likes: 47,
        comments: 8,
        media: [
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
          {
            type: "image",
            url: "/placeholder.svg?height=300&width=500",
          },
        ],
      },
    ],
  },
]
