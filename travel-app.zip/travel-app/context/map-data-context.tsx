"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface MapData {
  worldData: any
  countryNames: Map<string, string>
}

interface MapDataContextType {
  mapData: MapData | null
  setMapData: (data: MapData) => void
  isMapDataLoaded: boolean
}

const MapDataContext = createContext<MapDataContextType | undefined>(undefined)

export function MapDataProvider({ children }: { children: ReactNode }) {
  const [mapData, setMapData] = useState<MapData | null>(null)

  return (
    <MapDataContext.Provider
      value={{
        mapData,
        setMapData,
        isMapDataLoaded: !!mapData,
      }}
    >
      {children}
    </MapDataContext.Provider>
  )
}

export function useMapData() {
  const context = useContext(MapDataContext)
  if (context === undefined) {
    throw new Error("useMapData must be used within a MapDataProvider")
  }
  return context
}
